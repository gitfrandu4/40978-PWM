document.addEventListener('DOMContentLoaded', async () => {
    await loadCommonTemplates();

    const urlParams = new URLSearchParams(window.location.search);
    const itemId = parseInt(urlParams.get('id'));
    const type = window.location.pathname.includes('plant') ? 'plants' : 'animals';

    const data = await fetchData();
    const item = data[type].find(i => i.id === itemId);

    if (item) {
        trackClicks(itemId, type);

        const container = document.getElementById('main-content');
        container.innerHTML = `
      <article class="detail-card">
        <img src="${item.image}" alt="${item.name}" class="detail-img">
        <div class="detail-content">
          <h1>${item.name}</h1>
          <p>${item.description}</p>
          <p>Clicks totales: ${JSON.parse(localStorage.getItem(`${type}_clicks`))?.[itemId] || 0}</p>
        </div>
      </article>
    `;
    }
});
