document.addEventListener('DOMContentLoaded', async () => {
    await loadCommonTemplates();

    const data = await fetchData();
    const type = window.location.pathname.includes('plantas') ? 'plants' : 'animals';

    const container = document.getElementById('main-content');
    container.innerHTML = data[type].map(item => `
    <article class="card">
      <a href="${type.slice(0, -1)}.html?id=${item.id}" onclick="trackClicks(${item.id}, '${type}')">
        <img src="${item.image}" alt="${item.name}" class="card-img">
        <div class="card-content">
          <h3>${item.name}</h3>
          <p>${item.description}</p>
        </div>
      </a>
    </article>
  `).join('');
});
